const express = require('express')
const app = express()
const port = 3000
const mongoose=require('mongoose')
const bcrypt=require(bcrypt)
const SALT_WORK_FACTOR=10
app.use(express.json())
mongoose.connect('mongodb+srv://danielmoreno269:PfZxkX06eteQBoWt@clusterproyecto.dgfk0ze.mongodb.net/?retryWrites=true&w=majority&appName=ClusterProyecto',
             
              { useNewURLParser: true,
                useUnifiedTopology:true
              }
).then(()=>{
    console.log("Conectado a Atlas");

}).catch((err)=>{
    console.log('error conectado a atlas', err)
})

const userSchema= new mongoose.Schema({
    username: String,
    password: String

})
    // generate a salt
    
//Indicator on date and hour of the system waking up
const userSchema2= new mongoose.Schema({
    id: String,
    OnHour: String

})
//Indicator on date and hour of the system shutting down
const userSchema3= new mongoose.Schema({
    id: String,	
    Offhour: String

})
//Indicator on use of effect 1
const userSchema4= new mongoose.Schema({
    id: String,
    EFF1: Boolean

})
//Indicator on use of effect 2
const userSchema5= new mongoose.Schema({
    id: String,
    EFF2: Boolean

})
//Indicator on use of effect 3
const userSchema6= new mongoose.Schema({
    id: String,
    EFF3: Boolean

})
//Indicator on if there is a signal going through
const userSchema7= new mongoose.Schema({
    id: String,
    ACTV: Boolean

})
//Indicator on percentage of battery
const userSchema8= new mongoose.Schema({
    id: String,
    BTRY: Number

})

const modelouser=mongoose.model('User',userSchema)
const modelouser2=mongoose.model('User',userSchema2)
const modelouser3=mongoose.model('User',userSchema3)
const modelouser4=mongoose.model('User',userSchema4)
const modelouser5=mongoose.model('User',userSchema5)
const modelouser6=mongoose.model('User',userSchema6)
const modelouser7=mongoose.model('User',userSchema7)
const modelouser8=mongoose.model('User',userSchema8)
app.get('/', (req, res) => {
  res.send('Hello World!')
})
app.get('/temperatura', (req, res) => {
    console.log(req.query)
    res.send('ok')
  })
  app.post('/registro', async(req, res) => {
    console.log(req.body)
    let registro=req.body
    try{
        const newUser= new modelouser(registro)
        bcrypt.genSalt(SALT_WORK_FACTOR, function(err, salt) {
            if (err) return next(err);
        
            // hash the password along with our new salt
            bcrypt.hash(newouser.password, salt, function(err, hash) {
                if (err) return next(err);
         
                // override the cleartext password with the hashed one
                newuser.password = hash;
                next();
            });
        });
        await newUser.save()
        let payload={
            mensaje: 'registro escrito correctamente'
        }
        res.send(payload)
    }catch(err){
        let payload={
            mensaje: 'no se pudo guardar',
            error:err
        }

    }
    })
    async function checkUser(username, password) {
        //... fetch user from a db etc.
    
        const match = await bcrypt.compare(password, user.passwordHash);
    
        if(match) {
            //login
        }
    
        //...
    }
    app.post('/login', async(req, res) => {
        console.log(req.body)
        let registro=req.body
        try{   
        const loginUser= new modelouser2(login)
            //await newUser.save()
            let payload={
                mensaje: 'registro escrito correctamente'
            }
            res.send(payload)
        }catch(err){
            let payload={
                mensaje: 'no se pudo guardar',
                error:err
            }
    
        }})
app.post('/On', async(req, res) => {
    console.log(req.body)
    let on=req.body
    try{
        const newUser= new modelouser2(registro)
        await newUser.save()
        let payload={
            mensaje: 'Evento escrito correctamente'
        }
        res.send(payload)
    }catch(err){
        let payload={
            mensaje: 'no se pudo guardar',
            error:err
        }

    }    
    
  })
app.post('/Off', async(req, res) => {
    console.log(req.body)
    let on=req.body
    try{
        const newUser= new modelouser3(registro)
        await newUser.save()
        let payload={
            mensaje: 'Evento escrito correctamente'
        }
        res.send(payload)
    }catch(err){
        let payload={
            mensaje: 'no se pudo guardar',
            error:err
        }

    }    
    
  })
app.post('/EF1', async(req, res) => {
    console.log(req.body)
    let on=req.body
    try{
        const newUser= new modelouser4(registro)
        await newUser.save()
        let payload={
            mensaje: 'Evento escrito correctamente'
        }
        res.send(payload)
    }catch(err){
        let payload={
            mensaje: 'no se pudo guardar',
            error:err
        }

    }    
    
  })
app.post('/EF2', async(req, res) => {
    console.log(req.body)
    let on=req.body
    try{
        const newUser= new modelouser5(registro)
        await newUser.save()
        let payload={
            mensaje: 'Evento escrito correctamente'
        }
        res.send(payload)
    }catch(err){
        let payload={
            mensaje: 'no se pudo guardar',
            error:err
        }

    }    
    
  })
app.post('/EF3', async(req, res) => {
    console.log(req.body)
    let on=req.body
    try{
        const newUser= new modelouser6(registro)
        await newUser.save()
        let payload={
            mensaje: 'Evento escrito correctamente'
        }
        res.send(payload)
    }catch(err){
        let payload={
            mensaje: 'no se pudo guardar',
            error:err
        }

    }    
    
  })
app.post('/ACTV', async(req, res) => {
    console.log(req.body)
    let on=req.body
    try{
        const newUser= new modelouser7(registro)
        await newUser.save()
        let payload={
            mensaje: 'Evento escrito correctamente'
        }
        res.send(payload)
    }catch(err){
        let payload={
            mensaje: 'no se pudo guardar',
            error:err
        }

    }    
    
  })
app.post('/BTT', async(req, res) => {
    console.log(req.body)
    let on=req.body
    try{
        const newUser= new modelouser8(registro)
        await newUser.save()
        let payload={
            mensaje: 'Evento escrito correctamente'
        }
        res.send(payload)
    }catch(err){
        let payload={
            mensaje: 'no se pudo guardar',
            error:err
        }

    }    
    
  })
  